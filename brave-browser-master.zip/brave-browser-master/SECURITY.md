# Security Policy

## Supported Versions

All versions including and above the current stable release version number (the version downloadable on https://brave.com/download).

## Reporting a Vulnerability

See https://hackerone.com/brave for details.
