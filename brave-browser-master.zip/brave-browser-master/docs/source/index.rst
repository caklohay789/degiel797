.. Copyright (c) 2019 Brave Software


.. _rs_welcome:

Welcome to Brave Docs
---------------------

The next generation Brave desktop browser for macOS, Windows, and Linux.

.. _rs_community:

Brave Community Resources
-------------------------
* `community.brave.com <https://community.brave.com/>`_
* :doc:`/docs` process


Contents
--------

.. toctree::
   :maxdepth: 2

   installing-brave
   build-instructions
   docs

Indices and tables
------------------

* :ref:`genindex`
* :ref:`search`
