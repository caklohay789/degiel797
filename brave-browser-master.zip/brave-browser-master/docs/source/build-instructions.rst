Brave Build Instructions
************************

Build instructions are hosted in our `GitHub wiki <https://github.com/brave/brave-browser/wiki#build-instructions>`_ at this time.
